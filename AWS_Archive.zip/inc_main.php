<div id="layout">

	<!----------- MENU ---------->
    <!-- The home screen is about 3 things:
    Reminding users of the personal benefits of SYFG
    Showing new features/SYFG announcements
    Being a simple portal to all features of SYFG -->
    
	<?php include('menu_B.php'); ?>

	<div id="main">
        <div class="header">
            <h1>Welcome, FIRSTNAME LASTNAME</h1>
            <h2> Share Your Farming Gear</h2>
        </div>
	
        <div class="content">
            <h2 class="content-subhead">Home</h2>
            <p>You're currently searching for XX machines.  We have found XX mathes for you to inspect.</p>
            
            <p>Currently you have <href="#">XX Machines for rent</href>.  You have earned XXXX from renting them.</p>
                    <p>Currently you offer <href>XX contracting services</href>.  You have earned XXXX from contracting them.</p>
                    <p>Currently you have <href>XX active contracts</href> and <href>XX active insurance policies</href>.</p>
            <h3>New Features</h3>
            <p>The listing and searching functionality of the Share Your Farming Gear site went online on 1 March 2016.  New features will be progressively rolled out through 2016.
            </p>
        </div>

    </div>
</div>