<form class="pure-form">
    <fieldset>
        <legend>A compact inline form</legend>

        <label for="email">Email</label>
		<input id="email" type="email" placeholder="Email">
		<br>
        <input type="password" placeholder="Password">

        <label for="remember">
            <input id="remember" type="checkbox"> Remember me
        </label>

        <button type="submit" class="pure-button pure-button-primary">Sign in</button>
    </fieldset>
</form>
