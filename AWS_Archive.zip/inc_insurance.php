<div id="layout">

	<!----------- MENU ---------->
	<?php include('menu_B.php'); ?>

	<div id="main">
        <div class="header">
            <h1>User portal</h1>
        </div>
	
        <div class="content">
            <h2 class="content-subhead">Insurance</h2>
            <p>AJ loves my shorts.</p>
        </div>

    </div>
</div>