<?php include('header_A.php');?>

<div id="layout">

	<?php include('menu_A.php');?>

    <!------------ MENU ----------------->
	<div id="main">
        <div class="header">
            <h1>Your account</h1>
            <h2>Enter or modify your details</h2>
        </div>

		

		
        <div class="content">
		
            <h2 class="content-subhead">Credentials</h2>
			
			<?php include('form_itemA.php');?>
			
			
			<div class="pure-g">
				<div class="pure-u-1-2"><p>Thirds</p></div>
				<div class="pure-u-1-2"><p>Thirds</p></div>
			</div>


           
            <h2 class="content-subhead">Try Resizing your Browser</h2>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
        </div>

    </div>
</div>


<?php include('footer_A.php');?>



