    <!-- Menu toggle -->
    <a href="#menu" id="menuLink" class="menu-link">
        <!-- Hamburger icon -->
        <span></span>
    </a>

	<!------------ MENU ----------------->
	<div id="menu">
        <div class="pure-menu">
            <a class="pure-menu-heading" href="http://shareyourfarminggear.com.au/">Home</a>
            <ul class="pure-menu-list">
                <li class="pure-menu-item"><a href="index.php?act=login" class="pure-menu-link">Login</a></li>
                <li class="pure-menu-item"><a href="index.php?act=signup" class="pure-menu-link">Sign up</a></li>
				<li class="pure-menu-item"><a href="index.php?act=help" class="pure-menu-link">Help</a></li>
            </ul>
        </div>
		<div style="text-align: center; width: 100%; position: absolute; bottom: 0;"><img src="logo.png" alt="logo" width="60"></div>
    </div>