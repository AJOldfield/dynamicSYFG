<?php
/* DO NOT REMOVE */
if (!defined('QUADODO_IN_SYSTEM')) {
exit;
}
/*****************/
echo ADMIN_UPDATES_EXPLAIN;
?>
<br /><br /><br />
<iframe src="http://dev.quadodo.net/qls-<?php echo $qls->config['current_version']; ?>/updates.php" frameborder="0"></iframe>