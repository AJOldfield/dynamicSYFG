<div id="layout">

	<!----------- MENU ---------->
	<?php include('menu_A.php');?>

	<div id="main">
        <div class="header">
            <h1>Help</h1>
            <h2>I'm lost!</h2>
        </div>
	
        <div class="content">
            <h2 class="content-subhead">What went wrong?</h2>
            <p>Tell us what the problem is and we'll fix it! Send us an email at: xxxxxx@yyyy.com</p>
        </div>

    </div>
</div>