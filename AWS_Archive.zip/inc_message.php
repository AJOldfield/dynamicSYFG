<div id="layout">

	<!----------- MENU ---------->
	<?php include('menu_A.php');?>

	<div id="main">
        <div class="header">
            <h1>User portal</h1>
        </div>
	
        <div class="content">
            <h2 class="content-subhead">Message</h2>
            <?php echo "<p>$message</p>";?>
        </div>

    </div>
</div>