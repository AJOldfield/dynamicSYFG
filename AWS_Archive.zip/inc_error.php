<div id="layout">

	<!----------- MENU ---------->
	<?php include('menu_A.php');?>

	<div id="main">
        <div class="header">
            <h1>User portal</h1>
        </div>
	
        <div class="content">
            <h2 class="content-subhead">Error</h2>
            <?php echo "<p>$error_msg</p>";?>
			<p>Please <a href="javascript:history.go(-1)">go back</a> or <a href="http://shareyourfarminggear.com.au/Subsidiary/contact.html">contact us</a>.</p>
        </div>

    </div>
</div>