<div id="layout">

	<!----------- MENU ---------->
	<?php include('menu_B.php'); ?>

	<div id="main">
        <div class="header">
            <h1>My Account</h1>
            <h2>FIRSTNAME LASTNAME, USERNAME</h2>
        </div>
	
        <div class="content">
            <h2 class="content-subhead">Personal Data</h2>
            <p>Acccount Holder TABLE      
        
        </p>
              <h2 class="content-subhead">Payment History</h2>
            <p>Acccount Holder TABLE      
        
        </p>
              <h2 class="content-subhead">Current Listings</h2>
            <p>Acccount Holder TABLE      
        
        </p>
            </p>
              <h2 class="content-subhead">Current Searches</h2>
            <p>Acccount Holder TABLE      
        
        </p>
        </p>
              <h2 class="content-subhead">Current Agreements</h2>
            <p>Acccount Holder TABLE      
        
        </p>
        
        </div>

    </div>
</div>